﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthLogic : MonoBehaviour
{
    public float CurrentHealth = 100f;

    private void Start()
    {
        
    }
}
