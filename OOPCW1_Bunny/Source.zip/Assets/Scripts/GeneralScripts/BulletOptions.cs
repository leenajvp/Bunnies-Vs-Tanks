﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletOptions : MonoBehaviour
{
    public GameObject[] Bullets;
    public BulletSelection CurrentBullet;

    void Start()
    {

    }

    void Update()
    {

    }
}
