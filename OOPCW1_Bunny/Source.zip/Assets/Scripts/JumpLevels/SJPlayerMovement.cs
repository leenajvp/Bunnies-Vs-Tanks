﻿using System.Collections;
using UnityEngine;

public class SJPlayerMovement : MonoBehaviour
{
    public float Speed;

    public bool GroundCheck = true;
    public bool MineCollected = false;

    public GameObject mineBox;
    public GameObject mine;
    public GameObject itemDrop;
    public GameObject GameOver;

    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        StartCoroutine(GroundCheckRoutine());
        CalculateMovement();

        if (MineCollected == true)
        {
            DropMine();
        }

        if (gameObject.GetComponent<HealthLogic>().CurrentHealth <= 0)
        {
            GameOverScene();
        }
    }

    void CalculateMovement()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        transform.Translate(Vector2.right * horizontalInput * Speed * Time.deltaTime);
    }

    IEnumerator GroundCheckRoutine()
    {
        if (Input.GetKeyDown(KeyCode.W) && GroundCheck == true)
        {
            GroundCheck = false;
            float jumpVelocity = 5f;
            rb.velocity = Vector2.up * jumpVelocity;
            yield return new WaitForSeconds(1f);
            GroundCheck = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject == mineBox)
        {
            DropMine();
            MineCollected = true;
            Destroy(mineBox);
        }
    }

    public void DropMine()
    {
        if (Input.GetMouseButtonDown(1))
        {
            GameObject.Instantiate(mine, itemDrop.transform.position, Quaternion.identity);
        }
    }

    public void GameOverScene()
    {
        GameOver.SetActive(true);
        Speed = 0;
        Cursor.visible = true;
    }
}
