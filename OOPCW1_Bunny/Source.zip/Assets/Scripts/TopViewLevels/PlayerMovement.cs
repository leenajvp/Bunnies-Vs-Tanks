﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public GameObject GameOver;
    public GameObject mine;
    public GameObject mineBox;
    public GameObject itemDrop;

    public float HorizontalMoveSpeed;
    public float VerticalMoveSpeed;

    public bool mineCollected = false;

    void Start()
    {
        
    }

    void Update()
    {
        if (mineCollected == true)
        {
            DropMine();
        }

        if (Input.GetKey(KeyCode.A))
        {
            transform.position += Vector3.left * HorizontalMoveSpeed;
        }

        if (Input.GetKey(KeyCode.D))
        {
            transform.position += Vector3.right * HorizontalMoveSpeed;
        }

        if (Input.GetKey(KeyCode.W))
        {
            transform.position += Vector3.up * VerticalMoveSpeed;
        }

        if (Input.GetKey(KeyCode.S))
        {
            transform.position += Vector3.down * VerticalMoveSpeed;
        }

        if (gameObject.GetComponent<HealthLogic>().CurrentHealth <= 0)
        {
            GameOverScene();
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject == mineBox)
        {
            DropMine();
            mineCollected = true;
            Destroy(mineBox);
        }
    }

    public void GameOverScene()
    {
        GameOver.SetActive(true);
        HorizontalMoveSpeed = 0;
        VerticalMoveSpeed = 0;
        Cursor.visible = true;
    }

    public void DropMine()
    {
        if (Input.GetMouseButtonDown(1))
        {
            GameObject.Instantiate(mine, itemDrop.transform.position, Quaternion.identity);
        }
    }
}
